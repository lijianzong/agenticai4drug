# AgenticAI Sub-page — Technical Documentation

Sub-page for the **Agentic AI for Drug Discovery** project card, accessible via the "Try now" link on the main Scinnohub studio page.

---

## What This Sub-page Does

Embeds a fully interactive **Claude Code** session directly inside the browser. The user gets a real terminal — not a simulation — with live keystrokes, ANSI color codes, streaming output, and all interactive Claude Code features working exactly as they would in a native terminal.

---

## Architecture

```
Browser (xterm.js)
    │
    │  WebSocket  (ws://)
    │
Node.js Express Server  (server.js)
    │
    │  node-pty  (pseudo-terminal)
    │
Claude Code  (claude binary)
    └── registered as a native TTY process
```

### Why PTY (Pseudo-Terminal)?

A standard `child_process.spawn` gives Claude Code a pipe, not a terminal. Claude Code detects `isTTY === false` and disables colors, interactive prompts, and streaming rendering. By wrapping it in a **node-pty** pseudo-terminal:

- `process.stdout.isTTY === true` inside Claude Code
- `TERM=xterm-256color` and `COLORTERM=truecolor` are set in the environment
- `FORCE_COLOR=3` ensures full 24-bit color output
- All readline-based interactivity, progress bars, and real-time streaming work correctly

---

## Files

| File | Purpose |
|---|---|
| `server.js` | Node.js HTTP + WebSocket server; spawns Claude Code in a PTY and bridges I/O to the browser |
| `index.html` | Full-page terminal UI built with xterm.js; matches the main site's ice-cold glassmorphism design |
| `package.json` | Node.js dependencies: `express`, `ws`, `node-pty` |
| `.nvmrc` | Pins Node.js 18 LTS — required because Node 24's V8 headers use C++20 concepts that g++ 9 (Ubuntu 20.04) cannot compile |
| `AgenticAI.md` | This file |

---

## Server (`server.js`)

**Stack:** Express 4 · ws 8 · node-pty 1.x · Node.js 18 LTS

### Lifecycle per browser connection

1. A new WebSocket connection arrives from the browser.
2. `node-pty` spawns `claude` in a real PTY with `xterm-256color`, `truecolor`, and `FORCE_COLOR=3`.
3. **PTY → Browser:** every byte of PTY stdout is JSON-wrapped (`{ type: "output", data: "..." }`) and sent over the WebSocket. xterm.js writes it directly to the terminal renderer.
4. **Browser → PTY:** incoming WebSocket messages are parsed:
   - `{ type: "input", data }` — written to PTY stdin (keystrokes, pastes)
   - `{ type: "resize", cols, rows }` — calls `ptyProcess.resize()` so Claude Code reflows its output to match the actual visible terminal size
5. On WebSocket close (tab closed / network drop), the PTY process is killed immediately to avoid zombie Claude processes.
6. On PTY exit (user types `/exit` or `Ctrl+D`), a `{ type: "exit" }` message is sent to the browser and the session ends gracefully.

### Error handling

If the `claude` binary cannot be found or fails to start, the server sends a formatted error message directly into the terminal and closes the WebSocket cleanly — the user sees a red error in the terminal rather than a silent blank screen.

---

## Frontend (`index.html`)

**Stack:** xterm.js 5.3 · xterm addon-fit 0.8 · xterm addon-web-links 0.9 · Vanilla JS

### Terminal configuration

| Setting | Value | Reason |
|---|---|---|
| `fontFamily` | JetBrains Mono → Fira Code → Cascadia Code → Menlo | Ligature-capable monospace stack |
| `fontSize` | 14px | Comfortable density for drug discovery workflows |
| `scrollback` | 10 000 lines | Retains long molecule generation outputs |
| `cursorStyle` | bar | Standard IDE feel |
| `cursorBlink` | true | Active session indicator |
| `allowProposedApi` | true | Required for xterm.js v5 addons |

### Color theme (ice-lab palette)

The terminal uses a dark interior (`#0d1b2a`) while the surrounding page chrome uses the site's ice-cold light theme — matching the glassmorphism cards on the main page. The contrast prevents eye strain when reading dense molecular output.

| Role | Color |
|---|---|
| Background | `#0d1b2a` (deep blue-black) |
| Foreground | `#e2e8f0` (cool white) |
| Cursor | `#60a5fa` (electric blue) |
| Selection | `rgba(37,99,235,0.35)` |
| Green (success) | `#4ade80` |
| Red (error) | `#f87171` |
| Blue (info) | `#60a5fa` |
| Cyan (special) | `#22d3ee` |

### Addons loaded

- **FitAddon** — resizes the terminal columns/rows to exactly fill the container div. A `ResizeObserver` watches the container and calls `fitAddon.fit()` on any layout change, then immediately sends a `resize` message to the server so the PTY reflows.
- **WebLinksAddon** — makes URLs in Claude Code output clickable (e.g. documentation links, file paths).

### UI components

| Component | Description |
|---|---|
| **Header** | Fixed bar with "← Back to Studio" link, page title, "AI+" badge, and a live connection status pill |
| **Info bar** | Shows PTY type, engine, transport, renderer, and live terminal dimensions |
| **Terminal chrome** | macOS-style traffic-light dots + tab label — purely decorative, signals "this is a real terminal" |
| **Terminal container** | Dark `#0d1b2a` div that xterm.js renders into; fills all remaining viewport height via flexbox |
| **Offline banner** | Overlaid inside the terminal div when the WebSocket cannot connect; shows the exact `npm start` command needed |
| **Status bar** | Bottom strip with keyboard shortcut hints (Ctrl+C, Ctrl+D, Ctrl+L) |

### Connection state machine

```
         ┌──────────────┐
         │  Connecting… │  (on page load)
         └──────┬───────┘
                │ ws.onopen
         ┌──────▼───────┐
         │  Connected   │  (green pill, terminal active)
         └──────┬───────┘
       close /  │ error
    exit msg    │
         ┌──────▼─────────┐
         │  Disconnected  │  (Reconnect button shown)
         │  / Error       │  (Offline banner shown on error)
         └──────┬─────────┘
                │ user clicks Reconnect
         ┌──────▼───────┐
         │  Connecting… │
         └──────────────┘
```

---

## Dependency Resolution

### Node.js version constraint

Node.js 24's bundled V8 headers use C++20 language features (`requires` clauses, `concept` declarations) that **g++ 9** (the system compiler on Ubuntu 20.04) cannot parse — even with `-std=gnu++2a`. The `.nvmrc` file pins this project to **Node.js 18 LTS**, whose headers are compatible with g++ 9.

### Why not use a prebuilt binary?

`node-pty-prebuilt-multiarch` and similar packages do not yet ship prebuilt binaries for Node.js 24 on linux-x64. Compiling from source on Node 18 is the most reliable path on this system.

---

## Running Locally

```bash
# 1. Enter the project directory
cd AgenticAI

# 2. Activate Node 18 via nvm
source ~/.nvm/nvm.sh && nvm use 18

# 3. Start the server (dependencies already installed)
npm start
# → Agentic AI Terminal Server
# → http://localhost:3001

# 4. Open in browser
xdg-open http://localhost:3001
```

The main site's "Try now" button on the Agentic AI card links to `http://localhost:3001`. When the server is not running, the sub-page displays the offline banner with the exact command to start it.

---

## Future Expansion

| Item | Notes |
|---|---|
| **Authentication** | Add a session token / API key gate before spawning a PTY — essential before any public deployment |
| **Multi-session** | Each WebSocket already gets its own isolated PTY; add a session list UI for switching between concurrent Claude sessions |
| **Persistent history** | Write PTY output to a rolling log file per session; allow replay on reconnect |
| **HTTPS / WSS** | Switch Express to `https.createServer` with a TLS cert; the frontend auto-upgrades to `wss://` when `location.protocol === 'https:'` |
| **Docker** | Containerise with `claude` pre-installed; eliminates the Node version / compiler dependency entirely |
| **Sub-page routing** | Host all six project sub-pages under a single Express server; use `express.Router` per module |
