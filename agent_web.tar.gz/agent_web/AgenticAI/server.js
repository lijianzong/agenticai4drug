'use strict';

const express = require('express');
const http    = require('http');
const { WebSocketServer } = require('ws');
const pty     = require('node-pty');
const path    = require('path');
const os      = require('os');

const app    = express();
const server = http.createServer(app);

// ── WebSocket only on /ws  ───────────────────────────────────────────────────
// Using noServer mode so we can gate upgrades to a specific path.
// Any other upgrade request (e.g. random scanners) is rejected immediately.
const wss = new WebSocketServer({ noServer: true });

server.on('upgrade', (req, socket, head) => {
  if (req.url === '/ws') {
    wss.handleUpgrade(req, socket, head, (ws) => wss.emit('connection', ws, req));
  } else {
    socket.destroy();
  }
});

// ── Static files ─────────────────────────────────────────────────────────────
// Serve the entire agent_web/ parent directory at root so all pages are
// accessible from one origin — no cross-host issues for LAN visitors.
const siteRoot    = path.join(__dirname, '..');        // agent_web/
const terminalPage = path.join(__dirname, 'index.html'); // AgenticAI/index.html

app.use(express.static(siteRoot, { index: 'index.html' }));

// Explicit route for the terminal sub-page (avoids exposing server.js, node_modules, etc.)
app.get('/AgenticAI',  (_req, res) => res.redirect(301, '/AgenticAI/'));
app.get('/AgenticAI/', (_req, res) => res.sendFile(terminalPage));

// ── PTY → WebSocket bridge ───────────────────────────────────────────────────
wss.on('connection', (ws, req) => {
  const ip = req.socket.remoteAddress;
  console.log(`[PTY] new connection  ${ip}`);

  const claudePath = process.env.CLAUDE_BIN || 'claude';
  let ptyProc;

  try {
    ptyProc = pty.spawn(claudePath, [], {
      name: 'xterm-256color',
      cols: 220,
      rows: 50,
      cwd:  '/home/amax/Agent/claudecode',
      env:  {
        ...process.env,
        TERM:        'xterm-256color',
        COLORTERM:   'truecolor',
        FORCE_COLOR: '3',
      },
    });
    console.log(`[PTY] spawned claude  pid=${ptyProc.pid}`);
  } catch (err) {
    const msg = `\r\n\x1b[31m✖ Failed to start Claude Code: ${err.message}\x1b[0m\r\n` +
                `\r\n\x1b[33mMake sure 'claude' is on your PATH and try again.\x1b[0m\r\n`;
    try { ws.send(JSON.stringify({ type: 'output', data: msg })); } catch (_) {}
    try { ws.send(JSON.stringify({ type: 'exit',   code: 1   })); } catch (_) {}
    ws.close();
    return;
  }

  // PTY stdout → browser
  ptyProc.onData((data) => {
    try { ws.send(JSON.stringify({ type: 'output', data })); } catch (_) {}
  });

  ptyProc.onExit(({ exitCode }) => {
    console.log(`[PTY] claude exited  code=${exitCode}`);
    try { ws.send(JSON.stringify({ type: 'exit', code: exitCode })); } catch (_) {}
    try { ws.close(); } catch (_) {}
  });

  // Browser → PTY  (input | resize)
  ws.on('message', (raw) => {
    try {
      const msg = JSON.parse(raw.toString());
      if (msg.type === 'input') {
        console.log(`[PTY] input  → ${JSON.stringify(msg.data)}`);  // data relay log
        ptyProc.write(msg.data);
      } else if (msg.type === 'resize') {
        ptyProc.resize(
          Math.max(1, Math.min(msg.cols, 500)),
          Math.max(1, Math.min(msg.rows, 200))
        );
        console.log(`[PTY] resize → ${msg.cols}×${msg.rows}`);
      }
    } catch (_) {}
  });

  const cleanup = () => {
    console.log(`[PTY] cleanup  pid=${ptyProc?.pid}`);
    try { ptyProc.kill(); } catch (_) {}
  };
  ws.on('close', cleanup);
  ws.on('error', cleanup);
});

// ── Listen ───────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3001;

server.listen(PORT, '0.0.0.0', () => {
  // Collect all non-loopback IPv4 addresses so the user knows what URL to share
  const lanAddresses = [];
  for (const ifaces of Object.values(os.networkInterfaces())) {
    for (const iface of ifaces) {
      if (iface.family === 'IPv4' && !iface.internal) lanAddresses.push(iface.address);
    }
  }

  console.log('\n  Scinnohub — Agentic AI Terminal Server\n');
  console.log(`  Local   →  http://localhost:${PORT}`);
  for (const ip of lanAddresses) {
    console.log(`  Network →  http://${ip}:${PORT}   ← share this with LAN users`);
  }
  console.log(`\n  Terminal  →  /AgenticAI/`);
  console.log(`  WebSocket →  /ws\n`);
});
